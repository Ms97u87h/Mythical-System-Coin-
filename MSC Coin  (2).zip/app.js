let wallet = parseInt(localStorage.getItem("wallet") || "1000");
let coins = JSON.parse(localStorage.getItem("coins") || "[]");
let ticker = JSON.parse(localStorage.getItem("ticker") || "[]");

const rarities = ["Common", "Uncommon", "Rare", "Epic", "Legendary"];

function updateWallet() {
  const walletEl = document.getElementById("wallet-balance");
  if (walletEl) walletEl.textContent = wallet;
  localStorage.setItem("wallet", wallet);
}

function generateCoin() {
  const nameInput = document.getElementById("coinNameInput");
  const name = nameInput.value.trim() || `Coin${Math.floor(Math.random() * 1000)}`;
  const logo = `https://api.dicebear.com/7.x/thumbs/svg?seed=${encodeURIComponent(name)}`;
  const rarity = rarities[Math.floor(Math.random() * rarities.length)];
  const price = Math.floor(Math.random() * 100) + 1;
  
  const coin = {
    id: Date.now(),
    name,
    logo,
    rarity,
    price,
    votes: 0,
    history: []
  };
  
  coins.push(coin);
  localStorage.setItem("coins", JSON.stringify(coins));
  nameInput.value = "";
  alert(`Generated coin: ${coin.name}`);
}

function renderCoins() {
  const container = document.getElementById("coinCards");
  if (!container) return;
  
  container.innerHTML = "";
  coins.forEach(coin => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <img src="${coin.logo}" width="60"/>
      <h3>${coin.name}</h3>
      <p>${coin.rarity}</p>
      <p>Price: ${coin.price}</p>
      <button onclick="buyCoin(${coin.id})">Buy</button>
      <button onclick="sellCoin(${coin.id})">Sell</button>
      <button onclick="vote(${coin.id}, 1)">Upvote</button>
      <button onclick="vote(${coin.id}, -1)">Downvote</button>
      <p>Votes: ${coin.votes}</p>
    `;
    container.appendChild(card);
  });
  updateWallet();
}

function vote(id, val) {
  const coin = coins.find(c => c.id === id);
  if (!coin) return;
  coin.votes += val;
  ticker.push(`User ${val > 0 ? "upvoted" : "downvoted"} ${coin.name}`);
  save();
  renderCoins();
}

function buyCoin(id) {
  const coin = coins.find(c => c.id === id);
  if (!coin || wallet < coin.price) return;
  wallet -= coin.price;
  coin.history.push({ type: "buy", amount: coin.price });
  ticker.push(`User bought ${coin.name}`);
  save();
  renderCoins();
}

function sellCoin(id) {
  const coin = coins.find(c => c.id === id);
  const sellAmount = Math.floor(coin.price * 0.8);
  wallet += sellAmount;
  coin.history.push({ type: "sell", amount: sellAmount });
  ticker.push(`User sold ${coin.name}`);
  save();
  renderCoins();
}

function save() {
  localStorage.setItem("coins", JSON.stringify(coins));
  localStorage.setItem("wallet", wallet);
  localStorage.setItem("ticker", JSON.stringify(ticker));
}

function renderTrending() {
  const container = document.getElementById("trendingCoins");
  if (!container) return;
  const trending = coins.slice().sort((a, b) => b.votes - a.votes).slice(0, 5);
  container.innerHTML = trending.map(c => `<div class="card">${c.name} (${c.votes} votes)</div>`).join('');
}

function renderTicker() {
  const container = document.getElementById("liveTicker");
  if (!container) return;
  const latest = ticker.slice(-5).reverse();
  container.innerHTML = latest.map(t => `<p>${t}</p>`).join('');
}

// On load actions
document.addEventListener("DOMContentLoaded", () => {
  updateWallet();
  renderCoins();
  renderTrending();
  renderTicker();
});