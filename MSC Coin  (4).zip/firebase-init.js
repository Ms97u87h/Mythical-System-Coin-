// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyDTsemTzXPLVy1km2da36zeL1VWltUk-Dw",
  authDomain: "mythical-system-coin.firebaseapp.com",
  databaseURL: "https://mythical-system-coin-default-rtdb.firebaseio.com",
  projectId: "mythical-system-coin",
  storageBucket: "mythical-system-coin.appspot.com",
  messagingSenderId: "504520357456",
  appId: "1:504520357456:web:07012579f52b361f3fc355",
};
firebase.initializeApp(firebaseConfig);